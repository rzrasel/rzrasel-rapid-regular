# FRESUME

#### Make resumes for free

A responsive resume maker made with Flutter & Firebase. Features include Google Sign in, non logged in resume maker, saving and managing up to 3 resumes.

![Screenshot 2022-01-16 at 4 59 33 AM](https://user-images.githubusercontent.com/59999892/149656068-991e35c5-5d1d-489b-8222-7007f0d180dd.png)

![Screenshot 2022-01-16 at 5 19 59 AM](https://user-images.githubusercontent.com/59999892/149656086-a645d760-d84c-4108-9757-0a5bf99ab32d.png)
