import 'serving_item.dart';

const servingItems = [
  ServingItem(
    title: "Sippy Cups",
    text: "Are the new norm for iced coffee",
    imgUrl: "assets/images/sippy_cups.png",
  ),
  ServingItem(
    title: "Donut",
    text: "Have a donut with the frappuccinno",
    imgUrl: "assets/images/donut.png",
  ),
  ServingItem(
    title: "Cookies",
    text: "Enjoy our sugar free cookies",
    imgUrl: "assets/images/cookies.png",
  ),
];
