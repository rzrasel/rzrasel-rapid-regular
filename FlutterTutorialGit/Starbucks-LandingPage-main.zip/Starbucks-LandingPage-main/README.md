# starbucks_landing_page
### Landing page for Starbucks build with flutter.

It is a conceptual landing page for Starbucks which is built with Flutter. 
The website or say the page is made responsive for all practical devices and has different looks/configuration for mobile, tablet and the laptops or say the big screen devices.

## Snaps
### Desktop 
![desktop](https://user-images.githubusercontent.com/63596895/179342884-a313ad0e-be48-4d23-84a9-59a7846af1f1.png)
### Tablet
![tablet](https://user-images.githubusercontent.com/63596895/179342888-f9506f6d-e4a1-4b34-a3df-d8c70ac57c59.png)
### Mobile
![mobile](https://user-images.githubusercontent.com/63596895/179342893-f1c31cb2-6f39-4cc1-b6db-b853ad10e5ee.jpg)
