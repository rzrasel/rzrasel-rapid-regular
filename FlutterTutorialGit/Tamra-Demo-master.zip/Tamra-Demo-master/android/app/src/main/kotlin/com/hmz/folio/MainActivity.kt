package com.hmz.folio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
