## Responsive Live Resume using Flutter for web

Link: https://m-hamzashakeel.github.io/folio

<img src="https://user-images.githubusercontent.com/43790152/111952323-c8365280-8b06-11eb-9c65-747b5001340a.PNG">